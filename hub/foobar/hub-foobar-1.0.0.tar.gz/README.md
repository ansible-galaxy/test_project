# Ansible Collection - hub.foobar

Documentation for the collection.
